"""ml_model.py - trains a Bernoulli Naive Bayes model on the small CSV dataset.

Each symptom is a 0/1 feature. Naive Bayes computes, for every condition,
P(condition) x P(symptoms | condition) and normalises to probabilities.
"""
import os
import pandas as pd
from sklearn.naive_bayes import BernoulliNB

DATA = os.path.join(os.path.dirname(__file__), "data", "symptoms_dataset.csv")

def train_model():
    df = pd.read_csv(DATA)
    features = [c for c in df.columns if c != "condition"]
    model = BernoulliNB(alpha=1.0)  # alpha=1 -> Laplace smoothing
    model.fit(df[features], df["condition"])
    return model, features

def predict(model, features, selected, top_n=3):
    """Return the top conditions as [(condition, probability %), ...]."""
    row = pd.DataFrame([[1 if f in selected else 0 for f in features]], columns=features)
    probs = model.predict_proba(row)[0]
    ranked = sorted(zip(model.classes_, probs), key=lambda x: x[1], reverse=True)[:top_n]
    return [(c, round(p * 100, 1)) for c, p in ranked]
