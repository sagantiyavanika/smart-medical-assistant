"""symptoms.py - symptom list, text parsing, specialty mapping, explanations."""
import re

# key (dataset column) -> label shown to the user
SYMPTOMS = {
    "fever": "Fever", "cough": "Cough", "headache": "Headache", "sore_throat": "Sore throat",
    "fatigue": "Fatigue", "nausea": "Nausea", "vomiting": "Vomiting", "stomach_pain": "Stomach pain",
    "cold": "Cold", "body_pain": "Body pain", "skin_rash": "Skin rash", "itching": "Itching",
    "eye_redness": "Eye redness", "joint_pain": "Joint pain", "chest_pain": "Chest pain",
    "palpitations": "Palpitations",
}

# Words users may type -> symptom key (simple keyword matching)
KEYWORDS = {
    "fever": ["fever", "temperature"], "cough": ["cough"], "headache": ["headache", "head ache", "head hurts"],
    "sore_throat": ["sore throat", "throat pain", "throat"], "fatigue": ["fatigue", "tired", "weakness", "exhausted"],
    "nausea": ["nausea", "nauseous"], "vomiting": ["vomit", "throwing up"],
    "stomach_pain": ["stomach pain", "stomach ache", "stomachache", "abdominal", "tummy"],
    "cold": ["cold", "runny nose", "sneez"], "body_pain": ["body pain", "body ache", "muscle pain", "body aches"],
    "skin_rash": ["rash", "skin"], "itching": ["itch"], "eye_redness": ["red eye", "eye redness", "eyes are red", "eye"],
    "joint_pain": ["joint", "knee pain", "bone pain"], "chest_pain": ["chest pain", "chest"],
    "palpitations": ["palpitation", "heart racing", "racing heart", "fast heartbeat"],
}

def extract_symptoms(text):
    """Find known symptoms in free text like 'I have fever, headache and body pain'."""
    text = text.lower()
    return sorted({k for k, words in KEYWORDS.items() if any(re.search(re.escape(w), text) for w in words)})

# Condition -> specialty and a short explanation
CONDITION_INFO = {
    "Common Cold": ("General Physician", "A mild viral infection of the nose and throat. Rest, fluids and warmth usually help."),
    "Influenza": ("General Physician", "A viral infection (flu) with fever, body ache and tiredness. A doctor can advise on care."),
    "Viral Fever": ("General Physician", "Fever with tiredness and body pain, often from a viral infection."),
    "Migraine": ("Neurologist", "Severe, recurring headaches often with nausea. A neurologist can help find triggers and treatment."),
    "Gastroenteritis": ("Gastroenterologist", "Stomach/gut infection causing nausea, vomiting and pain. Stay hydrated and see a doctor if it persists."),
    "Allergic Skin Reaction": ("Dermatologist", "Rash and itching, often from allergens. A dermatologist can identify the cause."),
    "Conjunctivitis": ("Ophthalmologist", "Red, itchy eyes (pink eye). An eye specialist can confirm and treat it."),
    "Joint Inflammation (Arthritis)": ("Orthopedic", "Joint pain and stiffness. An orthopedic doctor can assess bones and joints."),
    "Possible Heart Concern": ("Cardiologist", "Chest pain or palpitations can be serious. Please seek medical attention promptly."),
}

# Red-flag symptoms shown with an emergency warning
EMERGENCY = {"chest_pain", "palpitations"}

DISCLAIMER = ("⚠️ This application provides educational health information only and is not a medical "
              "diagnosis. Please consult a qualified healthcare professional for medical advice. "
              "In an emergency, call your local emergency number immediately.")

def specialty_for(condition):
    return CONDITION_INFO.get(condition, ("General Physician", ""))[0]
