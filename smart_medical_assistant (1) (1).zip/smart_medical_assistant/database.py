"""database.py - SQLite setup. Creates tables and seeds sample doctors."""
import sqlite3, os

DB_PATH = os.path.join(os.path.dirname(__file__), "medical_assistant.db")

def get_conn():
    """Open a connection; rows behave like dictionaries."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

# Sample doctors: (name, specialty)
SAMPLE_DOCTORS = [
    ("Dr. Anil Kumar", "General Physician"),
    ("Dr. Meera Nair", "General Physician"),
    ("Dr. Sara Khan", "Dermatologist"),
    ("Dr. Rohit Verma", "Gastroenterologist"),
    ("Dr. Priya Rao", "Neurologist"),
    ("Dr. Imran Ali", "Ophthalmologist"),
    ("Dr. Suresh Reddy", "Orthopedic"),
    ("Dr. Kavita Sharma", "Cardiologist"),
]
SLOTS = ["10:00 AM", "11:30 AM", "2:00 PM", "4:30 PM"]

def init_db():
    """Create tables if missing and add sample doctors once."""
    conn = get_conn()
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL, password TEXT NOT NULL,
        age INTEGER, gender TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS doctors(
        id INTEGER PRIMARY KEY AUTOINCREMENT, doctor_name TEXT NOT NULL,
        specialty TEXT NOT NULL, available_date TEXT, available_time TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS appointments(
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
        doctor TEXT NOT NULL, specialty TEXT, date TEXT NOT NULL,
        time TEXT NOT NULL, status TEXT DEFAULT 'Booked',
        FOREIGN KEY(user_id) REFERENCES users(id))""")
    if c.execute("SELECT COUNT(*) FROM doctors").fetchone()[0] == 0:
        # 'Daily' means the doctor offers this time slot every day
        c.executemany("INSERT INTO doctors(doctor_name, specialty, available_date, available_time) VALUES(?,?,?,?)",
                      [(n, s, "Daily", t) for n, s in SAMPLE_DOCTORS for t in SLOTS])
    conn.commit()
    conn.close()
