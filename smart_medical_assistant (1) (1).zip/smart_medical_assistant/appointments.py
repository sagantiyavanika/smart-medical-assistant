"""appointments.py - doctors, free slots, booking, listing."""
from database import get_conn

def get_doctors(specialty=None):
    """Distinct doctors, optionally filtered by specialty."""
    conn = get_conn()
    q = "SELECT DISTINCT doctor_name, specialty FROM doctors"
    rows = conn.execute(q + (" WHERE specialty=?" if specialty else ""), (specialty,) if specialty else ()).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_specialties():
    conn = get_conn()
    rows = conn.execute("SELECT DISTINCT specialty FROM doctors ORDER BY specialty").fetchall()
    conn.close()
    return [r["specialty"] for r in rows]

def available_slots(doctor, date):
    """Doctor's slots for that date that are not already booked."""
    conn = get_conn()
    all_slots = [r["available_time"] for r in conn.execute(
        "SELECT available_time FROM doctors WHERE doctor_name=? ORDER BY id", (doctor,))]
    booked = {r["time"] for r in conn.execute(
        "SELECT time FROM appointments WHERE doctor=? AND date=? AND status='Booked'", (doctor, str(date)))}
    conn.close()
    return [s for s in all_slots if s not in booked]

def book_appointment(user_id, doctor, specialty, date, time):
    # Re-check the slot is still free to avoid double booking
    if time not in available_slots(doctor, date):
        return False, "Sorry, that slot was just taken. Please choose another."
    conn = get_conn()
    conn.execute("INSERT INTO appointments(user_id,doctor,specialty,date,time,status) VALUES(?,?,?,?,?,'Booked')",
                 (user_id, doctor, specialty, str(date), time))
    conn.commit(); conn.close()
    return True, "Appointment booked successfully."

def my_appointments(user_id):
    conn = get_conn()
    rows = conn.execute("SELECT id, doctor, specialty, date, time, status FROM appointments "
                        "WHERE user_id=? ORDER BY date DESC, time", (user_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def cancel_appointment(appt_id, user_id):
    conn = get_conn()
    conn.execute("UPDATE appointments SET status='Cancelled' WHERE id=? AND user_id=?", (appt_id, user_id))
    conn.commit(); conn.close()
