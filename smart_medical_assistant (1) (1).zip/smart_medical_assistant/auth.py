"""auth.py - registration, login, profile update, password change."""
import hashlib, hmac, os
from database import get_conn

def hash_password(password, salt=None):
    """PBKDF2-SHA256 with a random salt. Stored as 'salt$hash' (hex)."""
    salt = salt or os.urandom(16).hex()
    h = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), 100_000).hex()
    return f"{salt}${h}"

def verify_password(password, stored):
    salt, _ = stored.split("$")
    return hmac.compare_digest(hash_password(password, salt), stored)

def register_user(name, email, password, confirm, age, gender):
    """Returns (success, message)."""
    email = email.strip().lower()
    if not name.strip() or not email or not password:
        return False, "Please fill in all fields."
    if len(password) < 6:
        return False, "Password must be at least 6 characters."
    if password != confirm:
        return False, "Passwords do not match."
    conn = get_conn()
    try:
        conn.execute("INSERT INTO users(name,email,password,age,gender) VALUES(?,?,?,?,?)",
                     (name.strip(), email, hash_password(password), age, gender))
        conn.commit()
        return True, "Registration successful! You can now log in."
    except Exception:  # UNIQUE constraint on email
        return False, "This email is already registered."
    finally:
        conn.close()

def login_user(email, password):
    """Returns the user row if credentials are valid, else None."""
    conn = get_conn()
    user = conn.execute("SELECT * FROM users WHERE email=?", (email.strip().lower(),)).fetchone()
    conn.close()
    if user and verify_password(password, user["password"]):
        return dict(user)
    return None

def get_user(user_id):
    conn = get_conn()
    u = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    conn.close()
    return dict(u)

def update_profile(user_id, name, age, gender):
    conn = get_conn()
    conn.execute("UPDATE users SET name=?, age=?, gender=? WHERE id=?", (name.strip(), age, gender, user_id))
    conn.commit(); conn.close()

def change_password(user_id, old, new, confirm):
    if not verify_password(old, get_user(user_id)["password"]):
        return False, "Current password is incorrect."
    if len(new) < 6:
        return False, "New password must be at least 6 characters."
    if new != confirm:
        return False, "New passwords do not match."
    conn = get_conn()
    conn.execute("UPDATE users SET password=? WHERE id=?", (hash_password(new), user_id))
    conn.commit(); conn.close()
    return True, "Password changed successfully."
