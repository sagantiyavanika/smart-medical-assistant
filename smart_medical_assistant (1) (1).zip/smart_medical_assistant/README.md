# 🩺 Smart Medical Assistant

A beginner-friendly Streamlit app: register/login, check symptoms, get a simple ML-based
suggestion, find a specialist and book appointments.

> ⚠️ **Disclaimer:** Educational use only. It is **not** a medical diagnosis and does not replace
> a qualified healthcare professional or emergency care. In an emergency, call your local emergency number.

## Run
```bash
pip install -r requirements.txt
streamlit run app.py
```
The SQLite database (`medical_assistant.db`) and sample doctors are created automatically on first run.

## Structure
| File | Purpose |
|---|---|
| `app.py` | Streamlit UI, navigation, session state |
| `database.py` | SQLite tables + sample doctors |
| `auth.py` | Register, login, profile, password (PBKDF2 hashing) |
| `symptoms.py` | Symptom list, text parsing, specialty map, disclaimer |
| `ml_model.py` | Naive Bayes model |
| `appointments.py` | Slots, booking, listing, cancel |
| `data/symptoms_dataset.csv` | 27-row sample dataset |

## How it works
1. User registers/logs in (`st.session_state.user` holds the session).
2. Symptoms come from a multiselect, typed text, or the chatbot (keyword matching maps words → symptoms).
3. Symptoms become a 0/1 vector; the model outputs probabilities per condition.
4. The top condition maps to a specialty (`CONDITION_INFO`) with a short explanation.
5. The user books a free slot with a doctor of that specialty; it is saved in SQLite.

## ML model
**Bernoulli Naive Bayes** (scikit-learn). Each of 16 symptoms is a binary feature; each row is labelled
with one of 9 conditions. For a new input it computes `P(condition) × Π P(symptom | condition)` and
normalises to probabilities (Laplace smoothing `alpha=1` avoids zero probabilities). The dataset is tiny and
illustrative, so the confidence is **not clinically meaningful**.

## Database design
- `users(id, name, email UNIQUE, password 'salt$hash', age, gender)`
- `doctors(id, doctor_name, specialty, available_date, available_time)` – one row per doctor per slot ('Daily')
- `appointments(id, user_id → users.id, doctor, specialty, date, time, status)`

A slot is free if no `Booked` appointment exists for that doctor/date/time.

## Workflow
Register → Login → Dashboard → Symptom Checker → AI Analysis → Find Specialist → Book → My Appointments.

## Future improvements
Larger real dataset & model evaluation (accuracy, confusion matrix); NLP for symptom extraction;
per-doctor calendars and admin panel; email reminders; password reset; deployment with a hosted DB;
multi-language support.
