"""app.py - Streamlit UI for the Smart Medical Assistant. Run: streamlit run app.py"""
import datetime
import pandas as pd
import streamlit as st
import auth, appointments as appt
from database import init_db
from ml_model import train_model, predict
from symptoms import (SYMPTOMS, extract_symptoms, CONDITION_INFO, EMERGENCY, DISCLAIMER, specialty_for)

st.set_page_config(page_title="Smart Medical Assistant", page_icon="🩺", layout="wide")
init_db()

@st.cache_resource  # train once, reuse on every rerun
def load_model():
    return train_model()
model, features = load_model()

PAGES = ["🏠 Dashboard", "👤 My Profile", "🩺 Symptom Checker", "🤖 AI Health Analysis",
         "👨‍⚕️ Find Specialist", "📅 Book Appointment", "📋 My Appointments"]

# ---------- session state defaults ----------
for k, v in {"user": None, "symptoms": [], "chat": []}.items():
    st.session_state.setdefault(k, v)

# ---------- helpers ----------
def analyze(selected):
    """Return top predictions for the selected symptom keys."""
    return predict(model, features, selected)

def show_result(selected):
    """Display prediction, confidence, specialty and explanation."""
    preds = analyze(selected)
    top, conf = preds[0]
    specialty, why = CONDITION_INFO[top][0], CONDITION_INFO[top][1]
    if EMERGENCY & set(selected):
        st.error("🚨 Chest pain or palpitations can be serious. Seek urgent medical care if severe.")
    st.subheader(f"Possible condition: {top}")
    st.progress(int(conf), text=f"Model confidence: {conf}%")
    st.info(f"**Recommended specialty:** {specialty}\n\n{why}")
    with st.expander("Other possibilities"):
        st.table(pd.DataFrame(preds, columns=["Condition", "Probability (%)"]))
    st.warning(DISCLAIMER)

# ---------- login / register ----------
def auth_page():
    st.title("🩺 Smart Medical Assistant")
    st.warning(DISCLAIMER)
    tab_login, tab_reg = st.tabs(["Login", "Register"])
    with tab_login:
        with st.form("login"):
            email = st.text_input("Email / Username")
            pw = st.text_input("Password", type="password")
            if st.form_submit_button("Login"):
                user = auth.login_user(email, pw)
                if user:
                    st.session_state.user = user
                    st.rerun()
                else:
                    st.error("Invalid email or password.")
    with tab_reg:
        with st.form("register"):
            name = st.text_input("Full name")
            email = st.text_input("Email / Username", key="reg_email")
            c1, c2 = st.columns(2)
            pw = c1.text_input("Password", type="password", key="reg_pw")
            pw2 = c2.text_input("Confirm password", type="password")
            age = c1.number_input("Age", 1, 120, 25)
            gender = c2.selectbox("Gender", ["Male", "Female", "Other"])
            if st.form_submit_button("Register"):
                ok, msg = auth.register_user(name, email, pw, pw2, age, gender)
                (st.success if ok else st.error)(msg)

# ---------- pages ----------
def dashboard():
    st.title(f"Welcome, {st.session_state.user['name']} 👋")
    st.caption("Choose an option below.")
    cards = PAGES[1:]
    for row in (cards[:3], cards[3:]):
        cols = st.columns(3)
        for col, page in zip(cols, row):
            if col.button(page, use_container_width=True, key=f"card_{page}"):
                st.session_state.goto = page
                st.rerun()
    if st.button("🚪 Logout", use_container_width=True):
        logout()
    st.warning(DISCLAIMER)

def profile():
    st.title("👤 My Profile")
    u = auth.get_user(st.session_state.user["id"])
    st.write(f"**Email:** {u['email']}")
    with st.form("profile"):
        name = st.text_input("Name", u["name"])
        age = st.number_input("Age", 1, 120, int(u["age"] or 25))
        genders = ["Male", "Female", "Other"]
        gender = st.selectbox("Gender", genders, index=genders.index(u["gender"]) if u["gender"] in genders else 0)
        if st.form_submit_button("Update profile"):
            auth.update_profile(u["id"], name, age, gender)
            st.session_state.user["name"] = name
            st.success("Profile updated.")
    with st.expander("Change password"):
        with st.form("pwd"):
            old = st.text_input("Current password", type="password")
            new = st.text_input("New password", type="password")
            conf = st.text_input("Confirm new password", type="password")
            if st.form_submit_button("Change password"):
                ok, msg = auth.change_password(u["id"], old, new, conf)
                (st.success if ok else st.error)(msg)

def symptom_checker():
    st.title("🩺 Symptom Checker")
    st.warning(DISCLAIMER)
    tab1, tab2 = st.tabs(["Select symptoms", "💬 Chat"])
    with tab1:
        chosen = st.multiselect("Select your symptoms", list(SYMPTOMS), format_func=SYMPTOMS.get)
        text = st.text_input("Or type them", placeholder="e.g. I have fever, headache and body pain")
        if st.button("Save & analyze"):
            combined = sorted(set(chosen) | set(extract_symptoms(text)))
            if combined:
                st.session_state.symptoms = combined
                st.success("Symptoms saved: " + ", ".join(SYMPTOMS[s] for s in combined))
                show_result(combined)
            else:
                st.error("Please select or type at least one symptom.")
    with tab2:
        for role, msg in st.session_state.chat:
            st.chat_message(role).write(msg)
        prompt = st.chat_input("Describe how you feel...")
        if prompt:
            found = extract_symptoms(prompt)
            st.session_state.chat.append(("user", prompt))
            if found:
                st.session_state.symptoms = found
                top, conf = analyze(found)[0]
                reply = (f"I understood: **{', '.join(SYMPTOMS[s] for s in found)}**.\n\n"
                         f"A possible condition is **{top}** ({conf}% confidence). Consider seeing a "
                         f"**{specialty_for(top)}**. This is not a diagnosis.")
            else:
                reply = "I couldn't recognise any symptoms. Try e.g. 'I have fever and cough'."
            st.session_state.chat.append(("assistant", reply))
            st.rerun()

def analysis():
    st.title("🤖 AI Health Analysis")
    if not st.session_state.symptoms:
        st.info("No symptoms yet. Go to **Symptom Checker** first.")
        return
    st.write("**Your symptoms:** " + ", ".join(SYMPTOMS[s] for s in st.session_state.symptoms))
    show_result(st.session_state.symptoms)

def specialist():
    st.title("👨‍⚕️ Find Specialist")
    if st.session_state.symptoms:
        top, _ = analyze(st.session_state.symptoms)[0]
        sp = specialty_for(top)
        st.success(f"Based on your symptoms ({top}), we suggest a **{sp}**.")
    else:
        sp = st.selectbox("Choose a specialty", appt.get_specialties())
        st.caption("Tip: run the Symptom Checker for a personalised suggestion.")
    for d in appt.get_doctors(sp):
        st.write(f"👨‍⚕️ **{d['doctor_name']}** - {d['specialty']}")
    if st.button("Book with this specialty"):
        st.session_state.book_specialty = sp
        st.session_state.goto = "📅 Book Appointment"
        st.rerun()

def book():
    st.title("📅 Book Appointment")
    specs = appt.get_specialties()
    default = st.session_state.get("book_specialty")
    sp = st.selectbox("Specialty", specs, index=specs.index(default) if default in specs else 0)
    doctor = st.selectbox("Doctor", [d["doctor_name"] for d in appt.get_doctors(sp)])
    date = st.date_input("Date", min_value=datetime.date.today())
    slots = appt.available_slots(doctor, date)
    if not slots:
        st.error("No free slots on this date.")
        return
    slot = st.selectbox("Available time slots", slots)
    if st.button("Book appointment"):
        ok, msg = appt.book_appointment(st.session_state.user["id"], doctor, sp, date, slot)
        if ok:
            st.success(msg)
        else:
            st.error(msg)

def my_appointments():
    st.title("📋 My Appointments")
    rows = appt.my_appointments(st.session_state.user["id"])
    if not rows:
        st.info("You have no appointments yet.")
        return
    st.dataframe(pd.DataFrame(rows).drop(columns="id"), use_container_width=True)
    active = [r for r in rows if r["status"] == "Booked"]
    if active:
        pick = st.selectbox("Cancel an appointment", active,
                            format_func=lambda r: f"{r['doctor']} - {r['date']} {r['time']}")
        if st.button("Cancel selected"):
            appt.cancel_appointment(pick["id"], st.session_state.user["id"])
            st.rerun()

def logout():
    for k in ["user", "symptoms", "chat", "page", "book_specialty"]:
        st.session_state.pop(k, None)
    st.rerun()

# ---------- main ----------
if not st.session_state.user:
    auth_page()
else:
    # Apply dashboard-button navigation BEFORE the sidebar widget is created
    if "goto" in st.session_state:
        st.session_state.page = st.session_state.pop("goto")
    st.session_state.setdefault("page", PAGES[0])
    st.sidebar.title("🩺 Smart Medical Assistant")
    st.sidebar.write(f"Logged in as **{st.session_state.user['name']}**")
    st.sidebar.radio("Navigate", PAGES, key="page")
    if st.sidebar.button("🚪 Logout"):
        logout()
    st.sidebar.caption("Educational use only. Not a medical diagnosis.")
    {PAGES[0]: dashboard, PAGES[1]: profile, PAGES[2]: symptom_checker, PAGES[3]: analysis,
     PAGES[4]: specialist, PAGES[5]: book, PAGES[6]: my_appointments}[st.session_state.page]()
